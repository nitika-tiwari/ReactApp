# static-website-html-css
Static website with html and css
